const API = 'http://localhost:3000/api';
let usuarioAtual = null;
let idEditando = null;
let idAreaEditando = null;
let graficoAreas = null;
let graficoDias = null;

function mostrarTela(id) {
  document.querySelectorAll('.tela').forEach(t => t.classList.remove('ativa'));
  document.getElementById(id).classList.add('ativa');
}

function mostrarAba(idAba, btn) {
  document.querySelectorAll('.aba-conteudo').forEach(a => a.classList.remove('ativa'));
  document.querySelectorAll('.aba').forEach(a => a.classList.remove('ativa'));
  document.getElementById(idAba).classList.add('ativa');
  btn.classList.add('ativa');
  if (idAba === 'aba-dashboard') carregarDashboard();
}

// ============ FOTO ============
function previewFoto(event, previewId, hiddenId) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    const base64 = e.target.result;
    document.getElementById(hiddenId).value = base64;
    document.getElementById(previewId).innerHTML = '<img src="' + base64 + '">';
  };
  reader.readAsDataURL(file);
}

async function uploadFoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async function(e) {
    const base64 = e.target.result;
    const r = await fetch(API + '/foto', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ foto: base64 })
    });
    const j = await r.json();
    if (j.ok) {
      usuarioAtual.foto = base64;
      document.getElementById('foto-header-morador').innerHTML = '<img src="' + base64 + '">';
      alert('Foto atualizada!');
    }
  };
  reader.readAsDataURL(file);
}

// ============ CADASTRO ============
async function cadastrar() {
  const dados = {
    nome: document.getElementById('cad-nome').value.trim(),
    cpf: document.getElementById('cad-cpf').value.trim(),
    email: document.getElementById('cad-email').value.trim(),
    celular: document.getElementById('cad-celular').value.trim(),
    bloco: document.getElementById('cad-bloco').value.trim(),
    apartamento: document.getElementById('cad-ap').value.trim(),
    senha: document.getElementById('cad-senha').value,
    foto: document.getElementById('foto-cad').value
  };

  if (!dados.nome || !dados.cpf || !dados.email || !dados.celular || !dados.bloco || !dados.apartamento || !dados.senha) {
    mostrarMsg('cad-msg', 'Preencha todos os campos obrigatórios.', '#e74c3c');
    return;
  }

  try {
    const r = await fetch(API + '/cadastro', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const j = await r.json();
    if (j.erro) mostrarMsg('cad-msg', j.erro, '#e74c3c');
    else mostrarMsg('cad-msg', 'Cadastrado! Seu usuário é: ' + j.usuario + '. Verifique seu e-mail!', '#27ae60');
  } catch (e) {
    mostrarMsg('cad-msg', 'Erro de conexão.', '#e74c3c');
  }
}

function mostrarMsg(id, texto, cor) {
  const el = document.getElementById(id);
  el.textContent = texto;
  el.style.color = cor;
}

// ============ LOGIN ============
async function fazerLogin() {
  try {
    const r = await fetch(API + '/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        usuario: document.getElementById('login-usuario').value.trim(),
        senha: document.getElementById('login-senha').value
      })
    });
    const j = await r.json();
    if (j.erro) {
      document.getElementById('login-erro').textContent = j.erro;
      return;
    }
    usuarioAtual = j;
    if (j.tipo === 'admin') {
      mostrarTela('tela-admin');
      carregarAdmin();
    } else {
      document.getElementById('nome-morador').textContent = j.nome;
      document.getElementById('bloco-morador').textContent = j.bloco;
      document.getElementById('ap-morador').textContent = j.apartamento;
      if (j.foto) document.getElementById('foto-header-morador').innerHTML = '<img src="' + j.foto + '">';
      mostrarTela('tela-morador');
      carregarMorador();
    }
  } catch (e) {
    document.getElementById('login-erro').textContent = 'Erro de conexão.';
  }
}

async function sair() {
  await fetch(API + '/logout', { method: 'POST' });
  usuarioAtual = null;
  document.getElementById('login-usuario').value = '';
  document.getElementById('login-senha').value = '';
  document.getElementById('login-erro').textContent = '';
  mostrarTela('tela-login');
}

// ============ RECUPERAÇÃO DE SENHA ============
function mostrarRecuperar() {
  document.getElementById('modal-recuperar').classList.add('ativo');
}
function fecharRecuperar() {
  document.getElementById('modal-recuperar').classList.remove('ativo');
  document.getElementById('msg-recuperar').textContent = '';
}

async function enviarRecuperacao() {
  const email = document.getElementById('email-recuperar').value.trim();
  const msg = document.getElementById('msg-recuperar');
  if (!email) { msg.textContent = 'Digite seu e-mail.'; msg.style.color = '#e74c3c'; return; }
  
  const r = await fetch(API + '/recuperar-senha', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email })
  });
  const j = await r.json();
  msg.textContent = j.msg || 'E-mail enviado!';
  msg.style.color = '#27ae60';
}

// ============ MORADOR ============
async function carregarMorador() {
  await renderizarRecadosMorador();
  await renderizarCalendario('calendario', false);
  await renderizarMinhasReservas();
  await renderizarAreasMorador();
}

async function renderizarRecadosMorador() {
  const recados = await (await fetch(API + '/recados')).json();
  const cont = document.getElementById('lista-recados-morador');
  if (recados.length === 0) {
    cont.innerHTML = '<p style="color:#999;">Nenhum recado no momento.</p>';
    return;
  }
  cont.innerHTML = recados.map(r => 
    '<div class="recado-card"><h4>' + r.titulo + '</h4><p>' + r.mensagem + '</p>' +
    '<div class="meta"><span>' + r.autor + '</span><span>' + formatarData(r.data_criacao) + '</span></div></div>'
  ).join('');
}

async function renderizarAreasMorador() {
  const areas = await (await fetch(API + '/areas')).json();
  document.getElementById('areas-morador').innerHTML = areas.map(a => 
    '<div class="area-item"><h4>' + a.nome + '</h4><p>Cap: ' + a.capacidade + '</p></div>'
  ).join('');
}

async function renderizarCalendario(containerId, mostrarTodos) {
  const reservas = await (await fetch(API + '/reservas')).json();
  const eventos = reservas.map(r => ({
    title: r.area_nome + ' - ' + r.nome_morador,
    start: r.data,
    backgroundColor: '#667eea',
    borderColor: '#764ba2'
  }));

  const el = document.getElementById(containerId);
  el.innerHTML = '';
  const cal = new FullCalendar.Calendar(el, {
    initialView: 'dayGridMonth',
    locale: 'pt-br',
    height: 320,
    headerToolbar: {
      left: 'prev,next',
      center: 'title',
      right: 'today'
    },
    events: eventos,
    dateClick: async function(info) {
      if (mostrarTodos) return;
      const areas = await (await fetch(API + '/areas')).json();
      const areaId = await escolherArea(areas);
      if (!areaId) return;
      const r = await fetch(API + '/reservas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ area_id: areaId, data: info.dateStr })
      });
      const j = await r.json();
      if (j.erro) alert(j.erro);
      else { alert('Reserva confirmada! Verifique seu e-mail.'); carregarMorador(); }
    }
  });
  cal.render();
}

async function escolherArea(areas) {
  const lista = areas.map((a, i) => (i + 1) + ' - ' + a.nome).join('\n');
  const escolha = prompt('Escolha a área:\n' + lista);
  if (!escolha) return null;
  const idx = parseInt(escolha) - 1;
  return areas[idx] ? areas[idx].id : null;
}

async function renderizarMinhasReservas() {
  const todas = await (await fetch(API + '/reservas')).json();
  const minhas = todas.filter(r => r.usuario_id === usuarioAtual.id);
  const ul = document.getElementById('minhas-reservas');
  if (minhas.length === 0) {
    ul.innerHTML = '<li>Nenhuma reserva ainda. Clique em uma data no calendário!</li>';
    return;
  }
  ul.innerHTML = minhas.map(r => 
    '<li><span><b>' + r.area_nome + '</b> — ' + formatarData(r.data) + '</span>' +
    '<button class="btn-remover" onclick="cancelar(' + r.id + ', false)">Cancelar</button></li>'
  ).join('');
}

async function cancelar(id, ehAdmin) {
  if (!confirm('Cancelar reserva?')) return;
  await fetch(API + '/reservas/' + id, { method: 'DELETE' });
  if (ehAdmin) carregarAdmin(); else carregarMorador();
}

// ============ ADMIN ============
async function carregarAdmin() {
  await carregarDashboard();
  await renderizarAreasAdmin();
  await renderizarTodasReservas();
  await renderizarCalendario('calendario-admin', true);
  await renderizarUsuarios();
  await renderizarRecadosAdmin();
}

// DASHBOARD
async function carregarDashboard() {
  const d = await (await fetch(API + '/dashboard')).json();
  document.getElementById('stat-usuarios').textContent = d.totalUsuarios;
  document.getElementById('stat-reservas').textContent = d.totalReservas;
  document.getElementById('stat-mes').textContent = d.reservasMes;
  document.getElementById('stat-areas').textContent = d.totalAreas;

  // Gráfico de áreas
  const ctxAreas = document.getElementById('grafico-areas').getContext('2d');
  if (graficoAreas) graficoAreas.destroy();
  graficoAreas = new Chart(ctxAreas, {
    type: 'doughnut',
    data: {
      labels: d.reservasPorArea.map(a => a.nome),
      datasets: [{
        data: d.reservasPorArea.map(a => a.total),
        backgroundColor: ['#667eea', '#27ae60', '#f39c12', '#e74c3c', '#9b59b6', '#1abc9c']
      }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
  });

  // Gráfico de dias
  const ctxDias = document.getElementById('grafico-dias').getContext('2d');
  if (graficoDias) graficoDias.destroy();
  graficoDias = new Chart(ctxDias, {
    type: 'bar',
    data: {
      labels: d.reservasUltimos7.map(r => formatarData(r.data)),
      datasets: [{
        label: 'Reservas',
        data: d.reservasUltimos7.map(r => r.total),
        backgroundColor: '#667eea'
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
  });
}

async function renderizarAreasAdmin() {
  const areas = await (await fetch(API + '/areas')).json();
  document.getElementById('lista-areas-admin').innerHTML = areas.map(a => 
    '<li><span><b>' + a.nome + '</b> — capacidade: ' + a.capacidade + '</span>' +
    '<div><button class="btn-editar-area" onclick="abrirEdicaoArea(' + a.id + ', \'' + a.nome + '\', ' + a.capacidade + ')"><i class="fas fa-edit"></i></button>' +
    '<button class="btn-remover" onclick="excluirArea(' + a.id + ')">Excluir</button></div></li>'
  ).join('');
}

async function adicionarArea() {
  const nome = document.getElementById('nova-area-nome').value.trim();
  const capacidade = document.getElementById('nova-area-cap').value;
  if (!nome || !capacidade) return alert('Preencha os campos!');
  const r = await fetch(API + '/areas', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, capacidade: Number(capacidade) })
  });
  const j = await r.json();
  if (j.erro) alert(j.erro);
  else {
    document.getElementById('nova-area-nome').value = '';
    document.getElementById('nova-area-cap').value = '';
    renderizarAreasAdmin();
  }
}

function abrirEdicaoArea(id, nome, capacidade) {
  idAreaEditando = id;
  document.getElementById('edit-area-nome').value = nome;
  document.getElementById('edit-area-cap').value = capacidade;
  document.getElementById('modal-editar-area').classList.add('ativo');
}

function fecharModalArea() {
  document.getElementById('modal-editar-area').classList.remove('ativo');
  idAreaEditando = null;
}

async function salvarEdicaoArea() {
  const nome = document.getElementById('edit-area-nome').value.trim();
  const capacidade = document.getElementById('edit-area-cap').value;
  if (!nome || !capacidade) return alert('Preencha os campos!');
  const r = await fetch(API + '/areas/' + idAreaEditando, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nome, capacidade: Number(capacidade) })
  });
  const j = await r.json();
  if (j.erro) alert(j.erro);
  else {
    fecharModalArea();
    renderizarAreasAdmin();
    alert('Área atualizada!');
  }
}

async function excluirArea(id) {
  if (!confirm('Excluir área e suas reservas?')) return;
  await fetch(API + '/areas/' + id, { method: 'DELETE' });
  renderizarAreasAdmin();
}

async function renderizarTodasReservas() {
  const reservas = await (await fetch(API + '/reservas')).json();
  const ul = document.getElementById('todas-reservas');
  if (reservas.length === 0) {
    ul.innerHTML = '<li>Nenhuma reserva registrada.</li>';
    return;
  }
  ul.innerHTML = reservas.map(r => 
    '<li><span><b>' + r.area_nome + '</b> — ' + formatarData(r.data) + ' — ' + r.nome_morador + 
    ' (Bloco ' + r.bloco + ' Apto ' + r.apartamento + ')</span>' +
    '<button class="btn-remover" onclick="cancelar(' + r.id + ', true)">Cancelar</button></li>'
  ).join('');
}

async function renderizarUsuarios() {
  const usuarios = await (await fetch(API + '/usuarios')).json();
  const cont = document.getElementById('lista-usuarios');
  let html = '<table><thead><tr><th>Foto</th><th>Nome</th><th>Usuário</th><th>Bloco</th><th>Apto</th><th>Tipo</th><th>Status</th><th>Ações</th></tr></thead><tbody>';
  usuarios.forEach(u => {
    const fotoHtml = u.foto ? '<img src="' + u.foto + '" class="foto-tabela">' : '<i class="fas fa-user-circle" style="font-size:24px;color:#95a5a6"></i>';
    html += '<tr><td>' + fotoHtml + '</td><td>' + u.nome + '</td><td>' + u.usuario + '</td><td>' + u.bloco + 
            '</td><td>' + u.apartamento + '</td><td>' + u.tipo + 
            '</td><td class="' + (u.ativo ? 'status-ativo' : 'status-inativo') + '">' + 
            (u.ativo ? 'Ativo' : 'Inativo') + '</td><td>' +
            '<button class="btn-editar" onclick="abrirEdicao(' + u.id + ')">Editar</button>' +
            (u.usuario !== 'admin' ? ' <button class="btn-remover" onclick="excluirUsuario(' + u.id + ')">Excluir</button>' : '') +
            '</td></tr>';
  });
  html += '</tbody></table>';
  cont.innerHTML = html;
}

async function abrirEdicao(id) {
  const usuarios = await (await fetch(API + '/usuarios')).json();
  const u = usuarios.find(x => x.id === id);
  if (!u) return;
  idEditando = id;
  document.getElementById('edit-nome').value = u.nome;
  document.getElementById('edit-cpf').value = u.cpf;
  document.getElementById('edit-email').value = u.email;
  document.getElementById('edit-celular').value = u.celular;
  document.getElementById('edit-bloco').value = u.bloco;
  document.getElementById('edit-ap').value = u.apartamento;
  document.getElementById('edit-tipo').value = u.tipo;
  document.getElementById('edit-ativo').checked = u.ativo === 1;
  document.getElementById('foto-edit').value = u.foto || '';
  if (u.foto) document.getElementById('foto-preview-edit').innerHTML = '<img src="' + u.foto + '">';
  else document.getElementById('foto-preview-edit').innerHTML = '<i class="fas fa-user-circle"></i>';
  document.getElementById('modal-editar').classList.add('ativo');
}

function fecharModal() {
  document.getElementById('modal-editar').classList.remove('ativo');
  idEditando = null;
}

async function salvarEdicao() {
  const dados = {
    nome: document.getElementById('edit-nome').value.trim(),
    cpf: document.getElementById('edit-cpf').value.trim(),
    email: document.getElementById('edit-email').value.trim(),
    celular: document.getElementById('edit-celular').value.trim(),
    bloco: document.getElementById('edit-bloco').value.trim(),
    apartamento: document.getElementById('edit-ap').value.trim(),
    tipo: document.getElementById('edit-tipo').value,
    ativo: document.getElementById('edit-ativo').checked,
    foto: document.getElementById('foto-edit').value
  };
  const r = await fetch(API + '/usuarios/' + idEditando, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  });
  const j = await r.json();
  if (j.erro) alert(j.erro);
  else {
    fecharModal();
    renderizarUsuarios();
    alert('Usuário atualizado!');
  }
}

async function excluirUsuario(id) {
  if (!confirm('Excluir este usuário e suas reservas?')) return;
  const r = await fetch(API + '/usuarios/' + id, { method: 'DELETE' });
  const j = await r.json();
  if (j.erro) alert(j.erro);
  else renderizarUsuarios();
}

async function renderizarRecadosAdmin() {
  const recados = await (await fetch(API + '/recados')).json();
  const cont = document.getElementById('lista-recados-admin');
  if (recados.length === 0) {
    cont.innerHTML = '<p style="color:#999;">Nenhum recado publicado.</p>';
    return;
  }
  cont.innerHTML = recados.map(r => 
    '<div class="recado-card"><button class="btn-remover-recado" onclick="excluirRecado(' + r.id + ')">×</button>' +
    '<h4>' + r.titulo + '</h4><p>' + r.mensagem + '</p>' +
    '<div class="meta"><span>' + r.autor + '</span><span>' + formatarData(r.data_criacao) + '</span></div></div>'
  ).join('');
}

async function adicionarRecado() {
  const titulo = document.getElementById('recado-titulo').value.trim();
  const mensagem = document.getElementById('recado-mensagem').value.trim();
  if (!titulo || !mensagem) return alert('Preencha título e mensagem!');
  const r = await fetch(API + '/recados', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ titulo, mensagem, autor: usuarioAtual.nome })
  });
  const j = await r.json();
  if (j.erro) alert(j.erro);
  else {
    document.getElementById('recado-titulo').value = '';
    document.getElementById('recado-mensagem').value = '';
    renderizarRecadosAdmin();
    alert('Recado publicado!');
  }
}

async function excluirRecado(id) {
  if (!confirm('Excluir este recado?')) return;
  await fetch(API + '/recados/' + id, { method: 'DELETE' });
  renderizarRecadosAdmin();
}
// ============ CADASTRAR USUÁRIO (ADMIN) ============
function abrirModalCadastroUser() {
  document.getElementById('new-nome').value = '';
  document.getElementById('new-cpf').value = '';
  document.getElementById('new-email').value = '';
  document.getElementById('new-celular').value = '';
  document.getElementById('new-bloco').value = '';
  document.getElementById('new-ap').value = '';
  document.getElementById('new-usuario').value = '';
  document.getElementById('new-senha').value = '';
  document.getElementById('new-tipo').value = 'morador';
  document.getElementById('foto-new').value = '';
  document.getElementById('foto-preview-new').innerHTML = '<i class="fas fa-user-circle"></i>';
  document.getElementById('msg-new-user').textContent = '';
  document.getElementById('modal-cadastrar-user').classList.add('ativo');
}

function fecharModalCadastroUser() {
  document.getElementById('modal-cadastrar-user').classList.remove('ativo');
}

async function cadastrarUsuario() {
  const dados = {
    nome: document.getElementById('new-nome').value.trim(),
    cpf: document.getElementById('new-cpf').value.trim(),
    email: document.getElementById('new-email').value.trim(),
    celular: document.getElementById('new-celular').value.trim(),
    bloco: document.getElementById('new-bloco').value.trim(),
    apartamento: document.getElementById('new-ap').value.trim(),
    usuario: document.getElementById('new-usuario').value.trim(),
    senha: document.getElementById('new-senha').value,
    tipo: document.getElementById('new-tipo').value,
    foto: document.getElementById('foto-new').value
  };

  if (!dados.nome || !dados.cpf || !dados.email || !dados.celular || !dados.bloco || !dados.apartamento || !dados.usuario || !dados.senha) {
    document.getElementById('msg-new-user').textContent = 'Preencha todos os campos obrigatórios.';
    document.getElementById('msg-new-user').style.color = '#e74c3c';
    return;
  }

  const r = await fetch(API + '/usuarios', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(dados)
  });
  const j = await r.json();
  if (j.erro) {
    document.getElementById('msg-new-user').textContent = j.erro;
    document.getElementById('msg-new-user').style.color = '#e74c3c';
  } else {
    document.getElementById('msg-new-user').textContent = 'Usuário cadastrado com sucesso!';
    document.getElementById('msg-new-user').style.color = '#27ae60';
    setTimeout(() => {
      fecharModalCadastroUser();
      renderizarUsuarios();
    }, 1500);
  }
}
function formatarData(iso) {
  if (!iso) return '';
  const partes = iso.split('-');
  return partes[2] + '/' + partes[1] + '/' + partes[0];
}