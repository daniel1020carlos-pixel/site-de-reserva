const express = require('express');
const sqlite = require('better-sqlite3');
const bcrypt = require('bcrypt');
const cors = require('cors');
const session = require('express-session');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // para aceitar fotos em base64
app.use(express.static('public'));
app.use(session({
  secret: 'condominio_secret_2025',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 8 }
}));

const db = sqlite('./condominio.db');
db.pragma('journal_mode = WAL');

// Criar tabelas
db.exec(`
  CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    celular TEXT NOT NULL,
    bloco TEXT NOT NULL,
    apartamento TEXT NOT NULL,
    usuario TEXT UNIQUE NOT NULL,
    senha TEXT NOT NULL,
    tipo TEXT DEFAULT 'morador',
    ativo INTEGER DEFAULT 1,
    foto TEXT DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS areas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    capacidade INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS reservas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    area_id INTEGER,
    data TEXT NOT NULL,
    usuario_id INTEGER,
    nome_morador TEXT,
    bloco TEXT,
    apartamento TEXT,
    FOREIGN KEY(area_id) REFERENCES areas(id),
    FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
  );
  CREATE TABLE IF NOT EXISTS recados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titulo TEXT NOT NULL,
    mensagem TEXT NOT NULL,
    autor TEXT NOT NULL,
    data_criacao TEXT NOT NULL,
    ativo INTEGER DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS tokens_recuperacao (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER,
    token TEXT UNIQUE NOT NULL,
    data_expiracao TEXT NOT NULL,
    usado INTEGER DEFAULT 0
  );
`);

// Admin padrão
const adminExiste = db.prepare('SELECT id FROM usuarios WHERE usuario = ?').get('admin');
if (!adminExiste) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare(`INSERT INTO usuarios (nome, cpf, email, celular, bloco, apartamento, usuario, senha, tipo)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run('Administrador', '000.000.000-00', 'admin@condominio.com', '00000000000', 'ADM', '000', 'admin', hash, 'admin');
  console.log('✅ Admin criado: admin / admin123');
}

const areasExistentes = db.prepare('SELECT COUNT(*) as c FROM areas').get();
if (areasExistentes.c === 0) {
  const insert = db.prepare('INSERT INTO areas (nome, capacidade) VALUES (?, ?)');
  insert.run('Churrasqueira', 30);
  insert.run('Cinema', 20);
  insert.run('Salão de Festas', 80);
  insert.run('Quadra Esportiva', 40);
  insert.run('Piscina', 50);
  console.log('✅ Áreas padrão criadas');
}

// ============ CONFIGURAÇÃO DE E-MAIL ============
// ⚠️ SUBSTITUA pelos seus dados do Gmail
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 587,
  secure: false,
  family: 4,  // ← FORÇA IPv4 (resolve o erro!)
  auth: {
    user: 'carlosral899@gmail.com',
    pass: 'pumhuohydeoqsxag'
  }
});

async function enviarEmail(destino, assunto, html) {
  try {
    await transporter.sendMail({
      from: '"Condomínio Residencial" <nao-responder@condominio.com>',
      to: destino,
      subject: assunto,
      html
    });
    console.log('✅ E-mail enviado para', destino);
    return true;
  } catch (e) {
    console.error('❌ Erro ao enviar e-mail:', e.message);
    return false;
  }
}

// Validações
function validarCPF(cpf) {
  cpf = cpf.replace(/\D/g, '');
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
  let s = 0;
  for (let i = 0; i < 9; i++) s += parseInt(cpf[i]) * (10 - i);
  let d1 = (s * 10) % 11; if (d1 === 10) d1 = 0;
  if (d1 !== parseInt(cpf[9])) return false;
  s = 0;
  for (let i = 0; i < 10; i++) s += parseInt(cpf[i]) * (11 - i);
  let d2 = (s * 10) % 11; if (d2 === 10) d2 = 0;
  return d2 === parseInt(cpf[10]);
}

function validarEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
function validarCelular(c) { return /^\d{10,11}$/.test(c.replace(/\D/g, '')); }

function gerarUsuario(nome) {
  const partes = nome.trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .split(/\s+/).filter(p => p.length > 0);
  if (partes.length < 2) return partes[0];
  return partes[0] + '.' + partes[partes.length - 1];
}

// ============ ROTAS ============

// Cadastro
app.post('/api/cadastro', (req, res) => {
  try {
    const { nome, cpf, email, celular, bloco, apartamento, senha, foto } = req.body;
    
    if (!nome || !cpf || !email || !celular || !bloco || !apartamento || !senha)
      return res.status(400).json({ erro: 'Preencha todos os campos obrigatórios.' });
    if (!validarCPF(cpf)) return res.status(400).json({ erro: 'CPF inválido.' });
    if (!validarEmail(email)) return res.status(400).json({ erro: 'E-mail inválido.' });
    if (!validarCelular(celular)) return res.status(400).json({ erro: 'Celular inválido.' });
    if (senha.length < 6) return res.status(400).json({ erro: 'Senha com mínimo de 6 caracteres.' });

    const usuario = gerarUsuario(nome);
    const hash = bcrypt.hashSync(senha, 10);

    db.prepare(`INSERT INTO usuarios (nome, cpf, email, celular, bloco, apartamento, usuario, senha, foto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(nome, cpf, email, celular, bloco.toUpperCase(), apartamento.toUpperCase(), usuario, hash, foto || '');

    // Enviar e-mail de boas-vindas
    enviarEmail(email, 'Cadastro confirmado - Condomínio Residencial',
      `<div style="font-family: Arial; max-width: 500px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h2 style="color: #667eea;">Bem-vindo ao Condomínio! 🏢</h2>
        <p>Olá <b>${nome}</b>,</p>
        <p>Seu cadastro foi realizado com sucesso!</p>
        <div style="background: #f0f4f8; padding: 15px; border-radius: 8px; margin: 15px 0;">
          <p><b>Usuário:</b> ${usuario}</p>
          <p><b>Bloco:</b> ${bloco.toUpperCase()} | <b>Apartamento:</b> ${apartamento.toUpperCase()}</p>
        </div>
        <p>Guarde suas credenciais com cuidado.</p>
        <p style="color: #888; font-size: 12px;">Este é um e-mail automático, não responda.</p>
      </div>`);

    res.json({ ok: true, usuario });
  } catch (e) {
    console.error('Erro no cadastro:', e.message);
    if (e.message.includes('UNIQUE'))
      return res.status(400).json({ erro: 'CPF ou e-mail já cadastrado.' });
    res.status(500).json({ erro: e.message });
  }
});

// Login
app.post('/api/login', (req, res) => {
  try {
    const { usuario, senha } = req.body;
    const user = db.prepare('SELECT * FROM usuarios WHERE usuario = ? AND ativo = 1').get(usuario);
    if (!user || !bcrypt.compareSync(senha, user.senha))
      return res.status(401).json({ erro: 'Usuário ou senha inválidos.' });
    
    req.session.usuario = { 
      id: user.id, nome: user.nome, tipo: user.tipo, 
      email: user.email, bloco: user.bloco, apartamento: user.apartamento,
      foto: user.foto
    };
res.json({ 
  ok: true, 
  id: user.id,  // ← ADICIONAR ESTA LINHA
  tipo: user.tipo, 
  nome: user.nome, 
  bloco: user.bloco, 
  apartamento: user.apartamento, 
  foto: user.foto 
   });
  } catch (e) {
    console.error('Erro no login:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  if (!req.session.usuario) return res.status(401).json({ erro: 'Não logado' });
  res.json(req.session.usuario);
});

// RECUPERAÇÃO DE SENHA
app.post('/api/recuperar-senha', (req, res) => {
  try {
    const { email } = req.body;
    const user = db.prepare('SELECT * FROM usuarios WHERE email = ?').get(email);
    if (!user) return res.json({ ok: true, msg: 'Se o e-mail existir, enviaremos o link.' });

    const token = crypto.randomBytes(32).toString('hex');
    const expiracao = new Date(Date.now() + 3600000).toISOString(); // 1 hora

    db.prepare('INSERT INTO tokens_recuperacao (usuario_id, token, data_expiracao) VALUES (?, ?, ?)')
      .run(user.id, token, expiracao);

    const link = `http://localhost:3000/reset.html?token=${token}`;
    enviarEmail(email, 'Recuperação de senha - Condomínio',
      `<div style="font-family: Arial; max-width: 500px; margin: auto; padding: 20px;">
        <h2 style="color: #667eea;">Recuperação de senha 🔐</h2>
        <p>Olá ${user.nome},</p>
        <p>Você solicitou a recuperação de senha. Clique no link abaixo:</p>
        <a href="${link}" style="background: #667eea; color: white; padding: 12px 20px; text-decoration: none; border-radius: 6px; display: inline-block; margin: 15px 0;">Redefinir senha</a>
        <p style="color: #888; font-size: 12px;">Este link expira em 1 hora.</p>
      </div>`);

    res.json({ ok: true, msg: 'E-mail enviado com o link de recuperação.' });
  } catch (e) {
    console.error('Erro na recuperação:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

app.post('/api/redefinir-senha', (req, res) => {
  try {
    const { token, novaSenha } = req.body;
    if (novaSenha.length < 6) return res.status(400).json({ erro: 'Senha com mínimo de 6 caracteres.' });

    const tokenReg = db.prepare('SELECT * FROM tokens_recuperacao WHERE token = ? AND usado = 0 AND data_expiracao > datetime("now")').get(token);
    if (!tokenReg) return res.status(400).json({ erro: 'Token inválido ou expirado.' });

    const hash = bcrypt.hashSync(novaSenha, 10);
    db.prepare('UPDATE usuarios SET senha = ? WHERE id = ?').run(hash, tokenReg.usuario_id);
    db.prepare('UPDATE tokens_recuperacao SET usado = 1 WHERE id = ?').run(tokenReg.id);

    res.json({ ok: true });
  } catch (e) {
    console.error('Erro ao redefinir:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

// Áreas
app.get('/api/areas', (req, res) => res.json(db.prepare('SELECT * FROM areas').all()));
app.post('/api/areas', (req, res) => {
  const { nome, capacidade } = req.body;
  if (!nome || !capacidade) return res.status(400).json({ erro: 'Preencha os campos.' });
  const r = db.prepare('INSERT INTO areas (nome, capacidade) VALUES (?, ?)').run(nome, capacidade);
  res.json({ id: r.lastInsertRowid });
});
app.put('/api/areas/:id', (req, res) => {
  const { nome, capacidade } = req.body;
  db.prepare('UPDATE areas SET nome = ?, capacidade = ? WHERE id = ?').run(nome, capacidade, req.params.id);
  res.json({ ok: true });
});
app.delete('/api/areas/:id', (req, res) => {
  db.prepare('DELETE FROM reservas WHERE area_id = ?').run(req.params.id);
  db.prepare('DELETE FROM areas WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// Reservas
app.get('/api/reservas', (req, res) => {
  const sql = `SELECT r.*, a.nome as area_nome, u.email as email_morador
               FROM reservas r
               JOIN areas a ON a.id = r.area_id
               JOIN usuarios u ON u.id = r.usuario_id
               ORDER BY r.data DESC`;
  res.json(db.prepare(sql).all());
});

app.post('/api/reservas', (req, res) => {
  try {
    if (!req.session.usuario) return res.status(401).json({ erro: 'Não logado' });
    const { area_id, data } = req.body;
    const conflito = db.prepare('SELECT id FROM reservas WHERE area_id = ? AND data = ?').get(area_id, data);
    if (conflito) return res.status(400).json({ erro: 'Data já reservada.' });

    const u = req.session.usuario;
    const r = db.prepare(`INSERT INTO reservas (area_id, data, usuario_id, nome_morador, bloco, apartamento)
                          VALUES (?, ?, ?, ?, ?, ?)`)
                .run(area_id, data, u.id, u.nome, u.bloco, u.apartamento);

    const area = db.prepare('SELECT nome FROM areas WHERE id = ?').get(area_id);
    enviarEmail(u.email, 'Reserva confirmada - Condomínio',
      `<div style="font-family: Arial; max-width: 500px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
        <h2 style="color: #27ae60;">Reserva confirmada! ✅</h2>
        <p>Olá <b>${u.nome}</b>,</p>
        <div style="background: #f0f4f8; padding: 15px; border-radius: 8px; margin: 15px 0;">
          <p><b>Área:</b> ${area.nome}</p>
          <p><b>Data:</b> ${data}</p>
          <p><b>Bloco:</b> ${u.bloco} | <b>Apto:</b> ${u.apartamento}</p>
        </div>
        <p>Atenciosamente,<br>Administração do Condomínio</p>
      </div>`);

    res.json({ id: r.lastInsertRowid });
  } catch (e) {
    console.error('Erro na reserva:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

app.delete('/api/reservas/:id', (req, res) => {
  db.prepare('DELETE FROM reservas WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// USUÁRIOS
app.get('/api/usuarios', (req, res) => {
  res.json(db.prepare('SELECT id, nome, cpf, email, celular, bloco, apartamento, usuario, tipo, ativo, foto FROM usuarios').all());
});

app.put('/api/usuarios/:id', (req, res) => {
  const { nome, cpf, email, celular, bloco, apartamento, tipo, ativo, foto } = req.body;
  db.prepare(`UPDATE usuarios SET nome=?, cpf=?, email=?, celular=?, bloco=?, apartamento=?, tipo=?, ativo=?, foto=?
              WHERE id=?`)
    .run(nome, cpf, email, celular, bloco.toUpperCase(), apartamento.toUpperCase(), tipo, ativo ? 1 : 0, foto || '', req.params.id);
  res.json({ ok: true });
});

app.delete('/api/usuarios/:id', (req, res) => {
  if (req.params.id === '1') return res.status(400).json({ erro: 'Não é possível excluir o admin principal.' });
  db.prepare('DELETE FROM reservas WHERE usuario_id = ?').run(req.params.id);
  db.prepare('DELETE FROM usuarios WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ADMIN CADASTRAR USUÁRIO
app.post('/api/usuarios', (req, res) => {
  try {
    const { nome, cpf, email, celular, bloco, apartamento, usuario, senha, tipo, foto } = req.body;
    
    if (!nome || !cpf || !email || !celular || !bloco || !apartamento || !usuario || !senha)
      return res.status(400).json({ erro: 'Preencha todos os campos obrigatórios.' });
    if (!validarCPF(cpf)) return res.status(400).json({ erro: 'CPF inválido.' });
    if (!validarEmail(email)) return res.status(400).json({ erro: 'E-mail inválido.' });
    if (!validarCelular(celular)) return res.status(400).json({ erro: 'Celular inválido.' });
    if (senha.length < 6) return res.status(400).json({ erro: 'Senha com mínimo de 6 caracteres.' });

    const hash = bcrypt.hashSync(senha, 10);
    db.prepare(`INSERT INTO usuarios (nome, cpf, email, celular, bloco, apartamento, usuario, senha, tipo, foto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(nome, cpf, email, celular, bloco.toUpperCase(), apartamento.toUpperCase(), usuario, hash, tipo || 'morador', foto || '');

    res.json({ ok: true });
  } catch (e) {
    console.error('Erro ao cadastrar usuário:', e.message);
    if (e.message.includes('UNIQUE'))
      return res.status(400).json({ erro: 'CPF, e-mail ou usuário já cadastrado.' });
    res.status(500).json({ erro: e.message });
  }
});

// UPLOAD DE FOTO (base64)
app.post('/api/foto', (req, res) => {
  try {
    const { foto } = req.body;
    if (!req.session.usuario) return res.status(401).json({ erro: 'Não logado' });
    db.prepare('UPDATE usuarios SET foto = ? WHERE id = ?').run(foto, req.session.usuario.id);
    req.session.usuario.foto = foto;
    res.json({ ok: true, foto });
  } catch (e) {
    console.error('Erro ao salvar foto:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

// DASHBOARD
app.get('/api/dashboard', (req, res) => {
  try {
    const totalUsuarios = db.prepare("SELECT COUNT(*) as c FROM usuarios WHERE tipo = 'morador'").get().c;
    const totalReservas = db.prepare("SELECT COUNT(*) as c FROM reservas").get().c;
    const totalAreas = db.prepare("SELECT COUNT(*) as c FROM areas").get().c;
    const reservasMes = db.prepare("SELECT COUNT(*) as c FROM reservas WHERE strftime('%Y-%m', data) = strftime('%Y-%m', 'now')").get().c;
    
    const reservasPorArea = db.prepare(`
      SELECT a.nome, COUNT(r.id) as total 
      FROM areas a LEFT JOIN reservas r ON a.id = r.area_id 
      GROUP BY a.id
    `).all();

    const reservasUltimos7 = db.prepare(`
      SELECT data, COUNT(*) as total FROM reservas 
      WHERE data >= date('now', '-7 days') 
      GROUP BY data ORDER BY data
    `).all();

    res.json({
      totalUsuarios, totalReservas, totalAreas, reservasMes,
      reservasPorArea, reservasUltimos7
    });
  } catch (e) {
    console.error('Erro no dashboard:', e.message);
    res.status(500).json({ erro: e.message });
  }
});

// RECADOS
app.get('/api/recados', (req, res) => {
  res.json(db.prepare('SELECT * FROM recados WHERE ativo = 1 ORDER BY data_criacao DESC').all());
});

app.post('/api/recados', (req, res) => {
  const { titulo, mensagem, autor } = req.body;
  if (!titulo || !mensagem) return res.status(400).json({ erro: 'Preencha título e mensagem.' });
  const data = new Date().toISOString().split('T')[0];
  const r = db.prepare('INSERT INTO recados (titulo, mensagem, autor, data_criacao) VALUES (?, ?, ?, ?)')
              .run(titulo, mensagem, autor || 'Admin', data);
  res.json({ id: r.lastInsertRowid });
});

app.delete('/api/recados/:id', (req, res) => {
  db.prepare('UPDATE recados SET ativo = 0 WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ✅ DEPOIS (dinâmico - o Render vai definir a porta)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});